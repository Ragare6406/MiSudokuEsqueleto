package com.example.sudokuesqueleto;


public class RemovedNumber {
    public int row;
    public int col;
    public int value;

    public RemovedNumber(int row, int col, int value) {
        this.row = row;
        this.col = col;
        this.value = value;
    }
}
